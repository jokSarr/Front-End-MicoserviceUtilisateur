
<header>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid"  >
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-left">
                    <li>
                        <a href="@{/ChefDepartement/Accueil}"><span>Accueil</span></a>
                    </li>


                    <li>
                        <a href="@{/ChefDepartement/Formation}" ><span>Formations</span></a>
                    </li>



                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span> Syllabus</span><span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" style="background-color: #ffffff">
                            <li>
                                <a href="@{/ChefDepartement/UE}" ><span>UE</span></a>
                            </li>
                            <li>
                                <a href="@{/ChefDepartement/ECTout}" style="color: #000405"><span>EC</span></a>
                            </li>
                            <li><a ><span></span></a>
                            </li>
                        </ul>
                    </li>
                     <li>

                      <a><span>Syllabus</span></a>
                    </li>


                    <li>
                        <a href="@{/Chefdepartement/Enseignant}"><span>Enseignants</span></a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span>Enseignements</span><span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" style="background-color: #ffffff">
                            <li>
                                <a href="@{/ChefDepartement/EnseignementLister}" style="color: #000405"><span>Enseignements</span></a>
                            </li>
                            <li><a  href="@{/ChefDepartement/Repartition}"  style="color: #000405"><span>Enseignements--A Valider</span></a>
                            </li>
                            <li><a  href="@{/ChefDepartement/RepartitionValides}"  style="color: #000405"><span>Repartitions</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span>Emplois du Temps </span><span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" style="background-color: #ffffff">
                            <li>
                                <a href="@{/ChefDepartement/Seances}" style="color: #000405"><span>Ajout Seances</span></a>
                            </li>
                            <li><a   href="@{/ChefDepartement/Emplois_Temps}" style="color: #000405"><span>Emplois du Temps </span></a>
                            </li>
                        </ul>
                    </li>

                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span text="${prenom+'. '+nom}"></span><span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="@{/ChefDepartement/profile}"><span>Profil</span></a>
                            </li>
                            <li><a href="@{/logout}"><span>Deconnexion</span></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

export default navbar;